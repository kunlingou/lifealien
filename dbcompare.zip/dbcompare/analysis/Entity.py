class ExcelE:
    def __init__(self):
        self.title = ""
        self.fileName = ""
        self.url = ""
        self.file = ""
        self.connkey = ""
